package com.cognizant.mfpe.pensionManagementSystem.webportal.model;

public class AuthResponse {
	private String uid;
	private String name;
	private boolean isValid;

}
