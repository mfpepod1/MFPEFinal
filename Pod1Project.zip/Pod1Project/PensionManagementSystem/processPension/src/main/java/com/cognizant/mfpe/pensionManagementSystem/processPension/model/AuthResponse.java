package com.cognizant.mfpe.pensionManagementSystem.processPension.model;

public class AuthResponse {
	// User Id
	private String uid;
	//Username
	private String name;
	//Is Token valid
	private boolean isValid;
}
